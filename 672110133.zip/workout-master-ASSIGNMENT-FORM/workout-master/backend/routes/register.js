
const express = require("express");
const fs = require("fs");
const path = require("path");
const router = express.Router();

router.post("/", (req, res) => {
  const userData = req.body;
  const dataPath = path.join(__dirname, "../data/user.json");
  const users = JSON.parse(fs.readFileSync(dataPath, "utf8"));

  const existingUser = users.find(u => u.email === userData.email);
  if (existingUser) {
    return res.status(400).json({ message: "This email has already been used." });
  }

  users.push(userData);
  fs.writeFileSync(dataPath, JSON.stringify(users, null, 2));
  res.json({ message: "Register successfully" });
});

module.exports = router;
