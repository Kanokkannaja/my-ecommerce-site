console.log("register.js loaded");
document.addEventListener("DOMContentLoaded", () => {
  const categorySelect = document.getElementById("occupationCategory");
  const occupationSelect = document.getElementById("occupation");

  // โหลดหมวดหมู่อาชีพ
  async function loadOccupationCategories() {
    try {
      const response = await fetch("./json/occupation-cat.json");
      const categories = await response.json();

      categorySelect.innerHTML = '<option value="">Select Occupation Category</option>';
      categories.forEach(category => {
        const option = document.createElement("option");
        option.value = category;
        option.textContent = category;
        categorySelect.appendChild(option);
      });
    } catch (error) {
      console.error("Error loading occupation categories:", error);
    }
  }

  // โหลดอาชีพตามหมวดหมู่
  categorySelect.addEventListener("change", async () => {
    const selectedCategory = categorySelect.value.toLowerCase();
    if (!selectedCategory) return;

    try {
      const response = await fetch(`./json/${selectedCategory}.json`);
      const occupations = await response.json();

      occupationSelect.innerHTML = '<option value="">Select Occupation</option>';
      occupations.forEach(occupation => {
        const option = document.createElement("option");
        option.value = occupation;
        option.textContent = occupation;
        occupationSelect.appendChild(option);
      });
    } catch (error) {
      console.error("Error loading occupations:", error);
    }
  });

  // ส่งฟอร์ม REGISTER
  document.getElementById("registerForm").addEventListener("submit", async (e) => {
    e.preventDefault();

    const data = {
      firstName: document.getElementById("firstName").value.trim(),
      lastName: document.getElementById("lastName").value.trim(),
      email: document.getElementById("email").value.trim(),
      password: document.getElementById("password").value.trim(),
      category: categorySelect.value,
      occupation: occupationSelect.value
    };

    if (!data.firstName || !data.lastName || !data.email || !data.password || !data.category || !data.occupation) {
      alert("Please fill all fields.");
      return;
    }

    try {
      const res = await fetch("http://localhost:5000/api/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      const result = await res.json();
      alert(result.message);
    } catch (err) {
      alert("Error: " + err.message);
    }
  });

  // ส่งฟอร์ม LOGIN
  document.getElementById("loginForm").addEventListener("submit", async (e) => {
    e.preventDefault();

    const email = document.getElementById("loginEmail").value.trim();
    const password = document.getElementById("loginPassword").value.trim();

    if (!email || !password) {
      alert("Please enter both email and password.");
      return;
    }

    try {
      const res = await fetch("http://localhost:5000/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });

      const result = await res.json();
      alert(result.message);
    } catch (err) {
      alert("Error: " + err.message);
    }
  });

  // โหลด category ตอนโหลดหน้า
  loadOccupationCategories();
});

document.addEventListener("DOMContentLoaded", () => {
  const contactSection = document.getElementById("contact-section");
  const registerSection = document.getElementById("register-section");
  const loginSection = document.getElementById("login-section");

  const showOnly = (target) => {
    contactSection.style.display = "none";
    registerSection.style.display = "none";
    loginSection.style.display = "none";
    if (target) target.style.display = "block";
  };

  document.getElementById("btn-contact").addEventListener("click", (e) => {
    e.preventDefault();
    showOnly(contactSection);
  });

  document.getElementById("btn-register").addEventListener("click", (e) => {
    e.preventDefault();
    showOnly(registerSection);
  });

  document.getElementById("btn-login").addEventListener("click", (e) => {
    e.preventDefault();
    showOnly(loginSection);
  });

  // เริ่มต้นแสดง contact
  showOnly(contactSection);
});

